/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * Representa un ingrediente (componente) concreto.
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class IngredienteCarne extends IngredienteAbstracto {

	/**
	 * Constructor
	 * @param componente El componente al que hay que decorar.
	 */
	public IngredienteCarne(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=1.00;
	}

}


