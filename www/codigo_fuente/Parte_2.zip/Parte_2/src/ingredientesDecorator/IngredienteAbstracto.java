package ingredientesDecorator;

import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * Representa un decorador, cuyos componentes son las pizzas y los ingredientes de las mismas.
 * Se encargará de envolver al componente que decore mediante el patrón "Decorator".
 * @author Gonzalo Sánchez Pla.
 *
 */
public abstract class IngredienteAbstracto extends PizzaTodopizzaAbstracta {
	
	/**
	 * Componente que será decorado.
	 */
	protected PizzaTodopizzaAbstracta componente;
	
	/**
	 * Constructor en el que hay que enviar el componente a decorar como parámetro.
	 * @param componente objeto para decorar.
	 */
	public IngredienteAbstracto(PizzaTodopizzaAbstracta componente){
		this.componente=componente;
	}
	
	
	@Override
	public double obtenerPrecio() {
		return componente.obtenerPrecio() + this.precio;
	}


	/**
	 * Devuelve el componente al que el ingrediente envuelve.
	 * @return - objeto tipo PizzaTodopizzaAbstracta.
	 */
	public PizzaTodopizzaAbstracta obtenerComponente(){
		return componente;
	}	

	@Override
	public void preparar() {
		// TODO Auto-generated method stub
		componente.preparar();
	}

}
