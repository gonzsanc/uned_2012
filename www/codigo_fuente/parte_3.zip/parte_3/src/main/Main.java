package main;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Clase de prueba para el patrón Observer de la tercera parte de la práctica.
 * @author Gonzalo Sánchez Pla.
 *
 */
public class Main implements Runnable {
	
	
	/**
	 * Método main, punto de entrada. Lanza en un nuevo hilo una secuencia de instrucciones que demuestran el funcionamiento del patrón Observer.
	 * @param args No se utilizan.
	 */
	public static void main(String[] args){
		Main objeto = new Main();
		new Thread(objeto).start();
	}
	
	/**
	 * Punto de entrada en multihilo, que deriva el flujo del programa al método que demuestra el funcionamiento de observer.
	 */
	public void run(){
		iniciar();
	}

	/**
	 * Secuencia de instrucciones para demostrar el patrón Observer.
	 */
	private void iniciar(){
		
		//Creación de objetos sujeto observable y observador.
		pizzaGenerica sujeto = new pizzaGenerica();
		Observador observador = new Observador();
		
		//Adición de un objeto observador al sujeto (soporta múltiples observadores en relación 1 a n).
		sujeto.adscribir(observador);
		
		//Cambiamos de estado el sujeto observable para que el observador nos notifique el cambio.
		sujeto.asignarEstado("Preparando pedido");
		sujeto.preparar();
	}
	
	
	/**
	 * Sujeto concreto (clase interna de prueba)
	 * @author Gonzalo Sánchez Pla.
	 *
	 */
	 class pizzaGenerica extends patronObserver.SujetoAbstracto{
		 
		 
		public void preparar(){
			this.asignarEstado(Calendario.mostrarHora() + " - Preparando ingredientes");
			sleep(15);
			
			this.asignarEstado(Calendario.mostrarHora() + " - En el horno cocinándose");
			sleep(10);
	
			this.asignarEstado(Calendario.mostrarHora() + " - En el proceso de corte en porciones");
			sleep(5);
	
			this.asignarEstado(Calendario.mostrarHora() + " - Empaquetándola");
			sleep(2);
			
			this.asignarEstado(Calendario.mostrarHora() + " - Pizza lista para su recogida");
				}
		
		public void sleep(int tiempo){
			try {
				Thread.sleep(tiempo*1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	/**
	 * Observador concreto (clase interna de prueba)
	* @author Gonzalo Sánchez Pla.
	*
	*/
	 class Observador extends patronObserver.ObservadorAbstracto{
		 public Observador(){}
		
	}
	 
	 /**
	  * Clase interna de prueba para mostrar la hora y poder así comprobar las duraciones de los procesos de preparación.
	  * @author Gonzalo Sánchez Pla.
	  *
	  */
	 private static class Calendario{
		
		public static String mostrarHora(){
			GregorianCalendar calendario = new GregorianCalendar();
			String hora="";
			
			hora  += Integer.toString(calendario.get(Calendar.HOUR)) + ":";
			hora  += Integer.toString(calendario.get(Calendar.MINUTE)) + ":";
			hora  += Integer.toString(calendario.get(Calendar.SECOND));
			return hora;
		}
	 }
	
	
}
