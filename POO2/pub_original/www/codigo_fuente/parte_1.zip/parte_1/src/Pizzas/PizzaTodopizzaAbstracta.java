/**
 * 
 */
package Pizzas;

/**
 * Superclase para las pizzas. Facilita la implementación básica de la interfaz IPizzaTodopizza en los casos
 * que sea mejor la herencia.
 * @author Gonzalo Sánchez Pla.
 *
 */
public abstract class PizzaTodopizzaAbstracta implements IPizzaTodopizza {

	/**
	 * El tipo de pizza se asigna de tipo genérica por defecto en esta primera parte de la práctica.
	 */
	protected TipoPizza tipo=TipoPizza.genericaDePrueba;
	
	protected double precio=0;
	/* (non-Javadoc)
	 * @see Pizzas.IPizzaTodopizza#obtenerPrecio()
	 */
	@Override
	public double obtenerPrecio() {
		return precio;
	}

	/* (non-Javadoc)
	 * @see Pizzas.IPizzaTodopizza#asignarPrecio(double)
	 */
	@Override
	public void asignarPrecio(double precio) {
		this.precio=precio;

	}

	/* (non-Javadoc)
	 * @see Pizzas.IPizzaTodopizza#preparar()
	 */
	@Override
	public void preparar() {
		System.out.println();
		System.out.println("*******************************************************");
		System.out.println("Preparando piza tipo: " + tipo.toString());
		System.out.println("*******************************************************");
	}

}
