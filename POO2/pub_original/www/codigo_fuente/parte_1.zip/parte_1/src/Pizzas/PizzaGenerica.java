package Pizzas;

/**
 * Representa un producto concreto dentro de la interfaz Abstract Factory, y es genérico.
 * En la parte segunda de la práctica ya se implementará un patrón Factory Method para sustituir gestión de sublcases
 * de pizza por parte de la fábrica.
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class PizzaGenerica extends PizzaTodopizzaAbstracta {
	
	/**
	 * Tipo de pizza del catálogo de pizzas.
	 */
	protected TipoPizza tipo;
	
	/**
	 * Constructor.
	 */
	public PizzaGenerica(){
	}
}
