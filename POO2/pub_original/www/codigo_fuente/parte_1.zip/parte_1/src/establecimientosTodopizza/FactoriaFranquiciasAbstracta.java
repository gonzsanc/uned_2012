/**
 * 
 */
package establecimientosTodopizza;

import Pizzas.*;

/**
 * @author Gonzalo Sánchez Pla
 * Superclase para implementar el método abstract factory 
 */
public abstract class FactoriaFranquiciasAbstracta {
	
	
	/**
	 * Método para preparar un pedido de pizza. 
	 * @param tipo define el tipo de pizza que hay que preparar (su tamaño).
	 * @return Devuelve una pizza ya lista para llevar. En esta versión, la pizza aún no tiene ingredientes más que la base.
	 */
	public IPizzaTodopizza prepararPizza(TipoPizza tipo){
		
		IPizzaTodopizza pizza;
		
		//En esta versión preliminar no utilizamos aún el método fábrica para crear pizzas.
		switch (tipo){
		case genericaDePrueba:
				pizza=crearPizza(tipo);
			break;
			default:
				pizza=crearPizza(tipo);
			break;
		}
		
		
		//asignado el tamaño de la pizza, la preparamos.
		pizza.preparar();
		
		//Servimos la pizza preparada.
		return pizza;
	}
	
	/**
	 * Cada tipo de factoría deberá implementar esta clase.
	 * En caso de que todas o la mayor parte de las factorías creen el mismo tipo de pizza, entonces será mejor implementarla aquí.
	 * Y luego sobreescribir los métodos en la subclase que difiera.
	 * @param tipo el tipo de pizza que queremos preparar.
	 * @return un objeto de tipo pizza, según se prepare en cada factoría.
	 */
	protected abstract IPizzaTodopizza crearPizza(TipoPizza tipo);
	
	
	/**
	 * Este método es provisional y sirve para crear una pizza "genérica" de prueba para la primera parte.
	 * @return un objeto tipo pizza.
	 */
	protected  IPizzaTodopizza crearPizzaGenerica(){
		return new PizzaGenerica();
	}
	
}
