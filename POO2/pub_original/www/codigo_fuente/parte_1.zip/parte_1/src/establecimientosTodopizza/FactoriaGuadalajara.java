package establecimientosTodopizza;

import Pizzas.IPizzaTodopizza;
import Pizzas.TipoPizza;


/**
 * Clase tipo franquicia de la ciudad correspondiente.
 * @author Gonzalo Sánchez Pla
 *
 */
public final class FactoriaGuadalajara  extends FactoriaFranquiciasAbstracta{

	/* (non-Javadoc)
	 * @see establecimientosTodopizza.FactoriaFranquiciasAbstracta#crearPizza()
	 */
	@Override
	protected IPizzaTodopizza crearPizza(TipoPizza tipo) {
		// TODO Auto-generated method stub
		return this.crearPizzaGenerica();
	}

}
