/**
 * 
 */
package pizzaFactoryMethod;

/**
 * Superclase para las pizzas. Facilita la implementación básica de la interfaz IPizzaTodopizza en los casos
 * que sea mejor la herencia.
 * @author Gonzalo Sánchez Pla.
 */
public abstract class PizzaTodopizzaAbstracta implements IPizzaTodopizza{

	/**
	 * El tipo de pizza.
	 */
	protected TipoPizza tipo;
	
	/**
	 * Precio de este tipo de pizza.
	 */
	protected double precio;
	
	/**
	 * Estado de la pizza en el proceso de preparación.
	 */
	protected TiposEstadosPreparacion estado;
	
	/**
	 * Constructor
	 */
	public PizzaTodopizzaAbstracta(){
		tipo=TipoPizza.pendienteAsignacion;
		estado=TiposEstadosPreparacion.sinPreparar;
		precio=0;
	}
	
	
	/* (non-Javadoc)
	 * @see Pizzas.IPizzaTodopizza#obtenerPrecio()
	 */
	@Override
	public double obtenerPrecio() {
		return precio;
	}

	/* (non-Javadoc)
	 * @see Pizzas.IPizzaTodopizza#asignarPrecio(double)
	 */
	@Override
	public void asignarPrecio(double precio) {
		this.precio=precio;

	}

	/* (non-Javadoc)
	 * @see Pizzas.IPizzaTodopizza#preparar()
	 */
	@Override
	public void preparar() {
		System.out.println();
		System.out.println("*******************************************************");
		System.out.println("Preparando piza tipo: " + tipo.toString());
		System.out.println("*******************************************************");
		this.prepararIngredientes();
		this.cocinarEnHorno();
		this.cortarEnPorciones();
		this.empaquetarPizza();
		this.estado=TiposEstadosPreparacion.pizzaPreparada;
		System.out.println("¡Su pizza está lista, puede recogerla!");
	}
	
	
	/**
	 * Primera fase de preparación de las pizzas.
	 */
	protected void prepararIngredientes(){
		this.estado=TiposEstadosPreparacion.preparandoIngredientes;
		System.out.println("Preparando ingredientes...");
		try {
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Segunda fase de preparación de las pizzas.
	 */
	protected void cocinarEnHorno(){
		this.estado=TiposEstadosPreparacion.cocinandoEnHorno;
		System.out.println("Cocinando en horno...");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	/**
	 * Tercera fase de preparación de las pizzas.
	 */
	protected void cortarEnPorciones(){
		this.estado=TiposEstadosPreparacion.cortandoEnPorciones;
		System.out.println("Cortando pizza en porciones...");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Cuarta fase de preparación de las pizzas.
	 */
	protected void empaquetarPizza(){
		this.estado=TiposEstadosPreparacion.empaquetandoPizza;
		System.out.println("Empaquetando Pizza...");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
