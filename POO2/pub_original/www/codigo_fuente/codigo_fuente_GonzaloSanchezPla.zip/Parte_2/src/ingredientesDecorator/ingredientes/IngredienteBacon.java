/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class IngredienteBacon extends IngredienteAbstracto {

	/**
	 * @param componente
	 */
	public IngredienteBacon(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=0.75;
	}

}


