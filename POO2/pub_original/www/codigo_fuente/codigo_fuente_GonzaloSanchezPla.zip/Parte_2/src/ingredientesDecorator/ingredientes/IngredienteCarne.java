/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class IngredienteCarne extends IngredienteAbstracto {

	/**
	 * @param componente Un objeto de la familia con el que decorar.
	 */
	public IngredienteCarne(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=1.00;
	}

}


