/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class IngredientePina extends IngredienteAbstracto {

	/**
	 * @param componente
	 */
	public IngredientePina(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=0.25;
	}
}

