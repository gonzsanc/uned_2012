/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class IngredienteExtraDeQueso extends IngredienteAbstracto {

	/**
	 * @param componente
	 */
	public IngredienteExtraDeQueso(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=0.50;
	}

}
