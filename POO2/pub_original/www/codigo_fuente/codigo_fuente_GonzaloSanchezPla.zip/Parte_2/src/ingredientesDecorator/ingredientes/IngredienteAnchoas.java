/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * @author Gon
 *
 */
public final class IngredienteAnchoas extends IngredienteAbstracto {

	/**
	 * @param componente
	 */
	public IngredienteAnchoas(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=0.75;
	}

}


