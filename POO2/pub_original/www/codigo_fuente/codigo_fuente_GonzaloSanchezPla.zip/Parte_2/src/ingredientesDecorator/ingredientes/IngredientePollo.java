/**
 * 
 */
package ingredientesDecorator.ingredientes;

import ingredientesDecorator.IngredienteAbstracto;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class IngredientePollo extends IngredienteAbstracto {

	/**
	 * @param componente
	 */
	public IngredientePollo(PizzaTodopizzaAbstracta componente) {
		super(componente);
		precio=1.00;
	}

}

