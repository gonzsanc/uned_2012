/**
 * 
 */
package main;
import establecimientosTodopizza.*;
import establecimientosTodopizza.franquicias.FactoriaBarcelona;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;
import pizzaFactoryMethod.TipoPizza;
import ingredientesDecorator.*;
import ingredientesDecorator.ingredientes.*;

/**
 * @author Gon
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		FactoriaFranquiciasTodopizzaAbstracta fabrica;
		PizzaTodopizzaAbstracta pizza;
		IngredienteAbstracto pedido;
		
		fabrica = new FactoriaBarcelona();
		pizza= (PizzaTodopizzaAbstracta) fabrica.prepararPizza(TipoPizza.Grande); //15€
		
		pedido = new IngredienteBacon(pizza);  // Precio: .75
		pedido = new IngredienteExtraDeQueso(pedido); // Precio:  .5
		pedido = new IngredienteAceitunas(pedido); // Precio:  .5
		pedido = new IngredientePollo(pedido); //Precio:1
		
		System.out.println("Precio: " + pedido.obtenerPrecio());
		
	}

}
