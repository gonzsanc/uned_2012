package main;

import ingredientesDecorator.TiposIngredientes;
import patronObserver.ISujeto;
import patronObserver.ObservadorAbstracto;
import peticiones.FormularioPedido;
import peticiones.PreparadorPedidos;
import pizzaFactoryMethod.TiposEstadosPreparacion;
import pizzaFactoryMethod.PizzaTodopizzaAbstracta;

/**
 * Clase de prueba para la cuarta parte de la práctica (integración).
 * Con sólo dos objetos y la ejecución de tres métodos consigue realizar todo el ciclo completo de producción y servicio de pizzas.
 * El método hereda la clase Observador de manera que recibe las notificaciones de cambios de estado de las pizzas.
 * @author Gonzalo Sánchez Pla.
 */

public class Main extends ObservadorAbstracto{

	public static void main(String [] args){
		new Main();
	}
	
	public Main(){
		
		iniciar();
	}
	
	private void iniciar() {

		//Rellena un formulario con un pedido y lo dirige a una de las tiendas de la franquicia.
		
		//Main inscribe como objeto peticionario.
		FormularioPedido pedido  = new FormularioPedido(this);
		
		//Elige la franquicia de Guadalajara por su tipo.
		pedido.asginarFranquicia(establecimientosTodopizza.TiposFranquicia.guadalajara);
		
		//Elige los ingredientes de la pizza por su tipo.
		pedido.asignarTipoPizza(pizzaFactoryMethod.TipoPizza.XL);
		pedido.agregarIngrediente(TiposIngredientes.aceitunas);
		pedido.agregarIngrediente(TiposIngredientes.salami);
		pedido.agregarIngrediente(TiposIngredientes.extraQueso);
		pedido.agregarIngrediente(TiposIngredientes.pollo);
		pedido.agregarIngrediente(TiposIngredientes.pollo);

		//Entrega al gestor de pedidos el pedido y observa la evolución del mismo.
		PreparadorPedidos preparador = new PreparadorPedidos(pedido);
	}
	
	@Override
	public void actualizar(ISujeto sujeto) {
		
		TiposEstadosPreparacion estadoSujeto = ((PizzaTodopizzaAbstracta) sujeto).obtenerEstado();
		System.out.println("Observador es notificado del cambio en el sujeto " + sujeto.getClass().toString() + ": " + estadoSujeto);
		
		if  (estadoSujeto==TiposEstadosPreparacion.pizzaPreparada){
			System.out.println("Importe del pedido: " + Double.toString(((PizzaTodopizzaAbstracta) sujeto).obtenerPrecio()));
		}
	}

	
}
