package main;


import Pizzas.TipoPizza;
import establecimientosTodopizza.*;

/**
 * Método main requerido en la primera parte de la práctica para crear una factoría y una pizza genérica.
 * @author Gonzalo Sánchez Pla.
 *
 */
public final class Main {

	/**
	 * Crea un objeto fábrica con el patrón fábrica abstracta y genera un producto.
	 * @param args no utilizado.
	 */
	public static void main(String[] args) {
		
		
		
		FactoriaFranquiciasAbstracta fabrica = new FactoriaMadrid();
		fabrica.prepararPizza(TipoPizza.genericaDePrueba);
	}

}
