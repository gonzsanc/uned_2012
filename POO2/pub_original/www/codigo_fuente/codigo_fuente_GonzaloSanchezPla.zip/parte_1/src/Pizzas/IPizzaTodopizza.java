package Pizzas;

/**
 * Interfaz para la clase de objetos tipo Pizza.
 * Su función será representar una base de pizza la cual entrará en un proceso de pedido.
 * @author Gonzalo Sánchez Pla.
 *
 */
public interface IPizzaTodopizza {
	
		/**
		 * Devuelve el precio del objeto.
		 * @return precio del objeto.
		 */
		public double obtenerPrecio();
		
		/**
		 * Permite modificar el precio del objeto.
		 * @param precio Precio del objeto.
		 */
		public void asignarPrecio(double precio);
		
		/**
		 * Prepara la el pedido de pizza.
		 * Aunque en principio parece que este método no debería residir en el mismo objeto que es preparado,
		 * se trata de una previsión para implementar el patrón decorator y tratar al objeto como un pedido.
		 * Un pedido sí que debe implementar un proceso de preparación.
		 */
		public void preparar();
}
